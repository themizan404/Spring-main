/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.maven.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.spring.maven.model.Student;
import com.spring.maven.model.University;
import com.spring.maven.service.impl.IUniversityService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author B13
 */
@RestController
public class IndexController {
    @Autowired
    IUniversityService universityService;
    
   @RequestMapping("/")
    public ModelAndView index(){
        return new ModelAndView("index");
    }
    
     @RequestMapping("/login")
    public ModelAndView login(){
        return new ModelAndView("/admin/login");
    }
    
    @RequestMapping("/admin")
    public ModelAndView adminDashBoard(HttpServletRequest request){
        
        return new ModelAndView("/admin/university");
    }
    
    @RequestMapping("/department")
    public ModelAndView department(){
        List<University> uList=universityService.getAll();
        
        
        Map<String, Object> map=new HashMap<String, Object>();
        map.put("uList", uList);
        
        return new ModelAndView("/admin/department","map",map);
    }
    
    @RequestMapping("/semister")
    public ModelAndView semister(){
        return new ModelAndView("/admin/semister");
    }
            
    @RequestMapping("/courses")
    public ModelAndView courses(){
        return new ModelAndView("/admin/courses");
    }
    
    @RequestMapping("/students")
    public ModelAndView students(){
        return new ModelAndView("/admin/students");
    }
    
    @RequestMapping("/faculty")
    public ModelAndView faculty(){
        return new ModelAndView("/admin/faculty");
    }
    
    @RequestMapping("/library")
    public ModelAndView library(){
        return new ModelAndView("/admin/library");
    }
    
    @RequestMapping("/notice")
    public ModelAndView notice(){
        return new ModelAndView("/admin/notice");
    }
    
    
    //Faculty 
    
     @RequestMapping("/fLogin")
    public ModelAndView fLogin(){
        return new ModelAndView("/faculty/f_login");
    }
    
    @RequestMapping("/fStudent")
    public ModelAndView fStudent(){
        return new ModelAndView("/faculty/f_students");
    }
    
    @RequestMapping("/fNotice")
    public ModelAndView fNotice(){
        return new ModelAndView("/faculty/f_notice");
    }
    
    @RequestMapping("/fInfo")
    public ModelAndView fInfo(){
        return new ModelAndView("/faculty/f_info");
    }
    
    @RequestMapping("/fResult")
    public ModelAndView fResult(){
        return new ModelAndView("/faculty/f_result");
    }
    
    @RequestMapping("/fAttendance")
    public ModelAndView fAttendance(){
        return new ModelAndView("/faculty/f_attendance");
    }
    
    
    // for Student
    
    @RequestMapping("/sLogin")
    public ModelAndView sLogin(){
        return new ModelAndView("/student/s_login");
    }
    
    @RequestMapping("/sInfo")
    public ModelAndView sInfo(){
        return new ModelAndView("/student/s_info");
    }
    
    @RequestMapping("/sLibrary")
    public ModelAndView sLibrary(){
        return new ModelAndView("/student/s_library");
    }
    
    @RequestMapping("/sNotice")
    public ModelAndView sNotice(){
        return new ModelAndView("/student/s_notice");
    }
    
    @RequestMapping("/sResult")
    public ModelAndView sResult(){
        return new ModelAndView("/student/s_result");
    }
    
    @RequestMapping("/sAttendance")
    public ModelAndView sAttendance(){
        return new ModelAndView("/student/s_attendance");
    }
    
    
    
    @RequestMapping(value = "/getUniversity/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getAllEmployees(@PathVariable("id") int id) {
        
        System.out.println("...................... " + id);
        GsonBuilder gson = new GsonBuilder();
        Gson g = gson.create();
        University u=universityService.getById(id);
        return g.toJson(u);
    }
    
}
